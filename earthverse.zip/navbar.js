var subMenu = document.getElementById("subMenu");

function showMenu(){
if(subMenu.style.height ==="0vh"){
  subMenu.style.height = "25vh";
}
else{
  subMenu.style.height = "0vh"
}
}

